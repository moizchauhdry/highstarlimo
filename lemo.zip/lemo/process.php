<?php 
if(isset($_POST['submit'])){
    $to = "booking@highstarlimo.com"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $name = $_POST['name'];
    $subject = "Reservation";
    $message = "Mr. ".$name . " fill out the reservation form. His details are :" . "\n\n" . 
    "Name: ".$_POST['name']."\n".
    "Email: ".$_POST['email']."\n".
    "Phone: ".$_POST['phone']."\n".
    "Pick up Address: ".$_POST['pickup']."\n".
    "Destination Address: ".$_POST['destination']."\n".
    "Date Time: ".$_POST['datetime']."\n".
    "No. of Passangers: ".$_POST['nop']."\n".
    "No. of Lugages: ".$_POST['nol']."\n".
    "Vehicle: ".$_POST['vehicle']."\n".
    "Plan: ".$_POST['plan']."\n".
    "Message: ".$_POST['message']."\n";

    $headers = "From: ".$from."\r\n";
    $headers .= "Reply-To: ".$from."\r\n";
    $headers .= "Return-Path: ".$from."\r\n";
    
    $sent = mail($to,$subject,$message,$headers);
    header('Location: thankyou.php?success=true');
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }else{
        header('Location: reservation.php');
    }
?>