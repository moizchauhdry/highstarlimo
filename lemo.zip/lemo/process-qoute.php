<?php 
if(isset($_POST['submit'])){
    $to = "booking@highstarlimo.com"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $name = $_POST['name'];
    $subject = "Request a Qoute";
    $message = "Mr. ".$name . " fill out the qoute form. His details are :" . "\n\n" . 
    "Name: ".$_POST['name']."\n".
    "Email: ".$_POST['email']."\n".
    "Phone: ".$_POST['phone']."\n".
    "Pick up Address: ".$_POST['pickup']."\n".
    "Destination Address: ".$_POST['destination']."\n".
    "No. of Passangers: ".$_POST['nop']."\n".
    "No. of Lugages: ".$_POST['nol']."\n".
    "Instructions: ".$_POST['message']."\n";

    $headers = "From: ".$from."\r\n";
    $headers .= "Reply-To: ".$from."\r\n";
    $headers .= "Return-Path: ".$from."\r\n";
    $sent = mail($to,$subject,$message,$headers);
    header('Location: thank_you.php?success=true');
    // You can also use header('Location: thank_you.php'); to redirect to another page.
    }else{
        header('Location: qoute.php');
    }
?>