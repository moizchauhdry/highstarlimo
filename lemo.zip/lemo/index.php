<?php include('header.php');?> 
    <div class=content-wrapper>
        <div class=limoking-content>
            <div class=with-sidebar-wrapper>
                <section id=content-section-1>
                    <div class="limoking-full-size-wrapper gdlr-show-all no-skin" style="padding-bottom: 0px;  background-color: #ffffff; ">
                        <div class="limoking-master-slider-item limoking-slider-item limoking-item" style="margin-bottom: 0px;">
                            <div id=P_MS5c9b6f3967f07 class="master-slider-parent ms-parent-id-1">
                                <div id=MS5c9b6f3967f07 class="master-slider ms-skin-default">
                                    <div class=ms-slide data-delay=7 data-fill-mode=fill> 
                                    	<img src=plugins/masterslider/public/assets/css/blank.gif alt title data-src=upload/slider-item-1.jpg>
                                        <div class="ms-layer  msp-cn-2-1" style data-effect=t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n) data-duration=375 data-ease=easeOutQuint data-offset-x=0 data-offset-y=-111 data-origin=mc data-position=normal> The Best Limos</div>
                                        <div class="ms-layer  msp-cn-2-2" style data-effect=t(true,n,n,-500,n,n,n,n,n,n,n,n,n,n,n) data-duration=375 data-delay=300 data-ease=easeOutQuint data-offset-x=0 data-offset-y=-36 data-origin=mc data-position=normal> In New York</div>
                                        <div class="ms-layer  msp-cn-2-3" style data-effect=t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n) data-duration=325 data-delay=612 data-ease=easeOutQuint data-offset-x=0 data-offset-y=62 data-origin=mc data-position=normal> HIGHSTAR LIMO</div><img class=ms-layer src=plugins/masterslider/public/assets/css/blank.gif data-src=upload/slider-divider1.png alt style data-duration=337 data-delay=912 data-ease=easeOutQuint data-type=image data-offset-x=-114 data-offset-y=153 data-origin=mc data-position=normal><img class=ms-layer src=plugins/masterslider/public/assets/css/blank.gif data-src=upload/slider-divider1.png alt style data-duration=325 data-delay=900 data-ease=easeOutQuint data-type=image data-offset-x=116 data-offset-y=153 data-origin=mc data-position=normal>
                                        <div class="ms-layer  msp-cn-2-9" style="top:550px;" data-duration=325 data-delay=912 data-ease=easeOutQuint data-offset-x=0 data-offset-y=154 data-origin=mc data-position=normal> <a style="color: #fff;" href=about-us.php>About Us</a></div>
                                    </div>
                                    <div class=ms-slide data-delay=7 data-fill-mode=fill> 
                                    	<img src=plugins/masterslider/public/assets/css/blank.gif alt title data-src=upload/slider-item-2.jpg>
                                        <div class="ms-layer  msp-cn-2-10" style data-effect=t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n) data-duration=437 data-ease=easeOutQuint data-offset-x=3 data-offset-y=42 data-origin=ml data-position=normal> We Are #1 Limo Services</div>
                                        <div class="ms-layer  msp-cn-2-11" style data-effect=t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n) data-duration=437 data-delay=325 data-ease=easeOutQuint data-offset-x=2 data-offset-y=120 data-origin=ml data-position=normal> HIGHSTAR LIMO offers superb limo service in New York and Manhatatan.  We are the most popular and has
                                            <br/>been chosen by many important people. We also provide premier service to the airport, wedding,
                                            <br/>casino, sport event, proms etc.</div><a href=our-fleet.php target=_self class="ms-layer  msp-cn-1-12 ms-btn ms-btn-round ms-btn-n msp-preset-btn-159" data-effect=t(true,150,n,n,n,n,n,n,n,n,n,n,n,n,n) data-duration=412 data-delay=650 data-ease=easeOutQuint data-type=button data-offset-x=2 data-offset-y=204 data-origin=ml data-position=normal> See Our Fleet</a></div>
                                    <div class=ms-slide data-delay=7 data-fill-mode=fill> <img src=plugins/masterslider/public/assets/css/blank.gif alt title data-src=upload/slider-item-3.jpg>
                                        <div class="ms-layer  msp-cn-2-13" style data-effect=t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n) data-duration=362 data-ease=easeOutQuint data-offset-x=0 data-offset-y=75 data-origin=mc data-position=normal> Give Yourself</div><img class=ms-layer src=plugins/masterslider/public/assets/css/blank.gif data-src=upload/slider-3-divider.jpg alt style data-duration=312 data-delay=325 data-ease=easeOutQuint data-type=image data-offset-x=0 data-offset-y=139 data-origin=mc data-position=normal>
                                        <div class="ms-layer  msp-cn-2-14" style data-effect=t(true,n,n,500,n,n,n,n,n,n,n,n,n,n,n) data-duration=362 data-delay=575 data-ease=easeOutQuint data-offset-x=0 data-offset-y=186 data-origin=mc data-position=normal> A New Experience</div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class=clear></div>
                        <div class=clear></div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-2>
                    <div class="limoking-parallax-wrapper limoking-background-image gdlr-show-all limoking-skin-dark-skin" id=limoking-parallax-wrapper-1 data-bgspeed=0 style="background-image: url('upload/fleet-bg-hp1.jpg'); background-repeat: repeat-x;padding-top: 72px; padding-bottom: 430px; ">
                        <div class=container>
                            <div class=limoking-title-item>
                                <div class="limoking-item-title-wrapper limoking-item  limoking-center-icon-divider limoking-large ">
                                    <div class="limoking-item-title-container container">
                                        <div class=limoking-item-title-head-inner>
                                            <h3 class="limoking-item-title limoking-skin-title limoking-skin-border">We are top 10 Best Airport Shuttles in New York</h3></div>
                                        <div class=limoking-nav-title>
                                            <div class=limoking-item-title-content-icon-divider-wrapper>
                                                <div class=limoking-item-title-center-icon-divider></div><i class="fa fa-star"></i>
                                                <div class=limoking-item-title-center-icon-divider></div>
                                            </div>
                                        </div>
                                        <div class="limoking-item-title-caption limoking-skin-info">We provide best Limo service in Westchester County and Connecticut</div>
                                    </div>
                                </div>
                            </div>
                            <div class=clear></div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-3>
                    <div class="limoking-color-wrapper  gdlr-show-all no-skin" style="background-color: #ffffff; padding-top: 0px; padding-bottom: 10px; ">
                        <div class=container>
                            <div class="limoking-item-title-wrapper limoking-item  limoking-nav-container limoking-center-icon-divider limoking-medium ">
                                <div class="limoking-item-title-container container">
                                    <div class=limoking-item-title-head-inner>
                                        <h3 class="limoking-item-title limoking-skin-title limoking-skin-border">Our Fleet</h3></div>
                                    
                                        
                                </div>
                            </div>
                            <div class="car-item-wrapper type-modern-car">
                                <div class="car-item-holder  limoking-car-column-3">
                                    <div class="limoking-car-carousel-item limoking-item">
                                        <div class=flexslider data-type=carousel data-nav-container=car-item-wrapper data-columns=3>
										<ul class=slides>
										   
										   <li class="limoking-item limoking-car-item limoking-modern-car">
										      <div class=car-thumbnail>
										         <img src=images/fleet-1.png alt width=600 height=343>
										         <span class=car-overlay>&nbsp;</span>
										         <a class=car-overlay-icon href=reservation.php>
										         <span class=car-icon >
										         <i class="fa fa-link" ></i>
										         </span>
										         </a>
										      </div>
										      <h3 class="car-title">
										         <a href=reservation.php >Hire This Car</a>
										      </h3>
										   </li>
                                           <li class="limoking-item limoking-car-item limoking-modern-car">
										      <div class=car-thumbnail>
										         <img src=images/fleet-2.png alt width=600 height=343>
										         <span class=car-overlay>&nbsp;</span>
										         <a class=car-overlay-icon href=reservation.php>
										         <span class=car-icon >
										         <i class="fa fa-link" ></i>
										         </span>
										         </a>
										      </div>
										      <h3 class="car-title">
										         <a href=reservation.php >Hire This Car</a>
										      </h3>
										   </li>
                                           <li class="limoking-item limoking-car-item limoking-modern-car">
										      <div class=car-thumbnail>
										         <img src=images/fleet-3.png alt width=600 height=343>
										         <span class=car-overlay>&nbsp;</span>
										         <a class=car-overlay-icon href=reservation.php>
										         <span class=car-icon >
										         <i class="fa fa-link" ></i>
										         </span>
										         </a>
										      </div>
										      <h3 class="car-title">
										         <a href=reservation.php >Hire This Car</a>
										      </h3>
										   </li>

										</ul>
                                        </div>
                                    </div>
                                    <div class=clear></div>
                                </div>
                            </div>
                            <div class=clear></div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-4>
                    <div class="limoking-parallax-wrapper limoking-background-image gdlr-show-all limoking-skin-darkblue" id=limoking-parallax-wrapper-2 data-bgspeed=0 style="background-image: url('upload/about-us-bg1.jpg'); padding-top: 95px; padding-bottom: 50px; ">
                        <div class=container>
                            <div class="six columns">
                                <div class="limoking-item limoking-about-us-item limoking-with-divider">
                                    <div class=about-us-title-wrapper>
                                        <h3 class="about-us-title">We promise to provide the best experience</h3>
                                        <div class=about-us-title-divider></div>
                                    </div>
                                    <div class=about-us-content-wrapper>
                                        <div class="about-us-content limoking-skin-content">
                                            
                                        </div><a class="about-us-read-more limoking-button large" href=reservation.php >Book Now</a>

                                    </div>
                                    <div class=clear></div>
                                </div>
                            </div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-5>
                    <div class="limoking-color-wrapper  gdlr-show-all limoking-skin-dark-skin" style=" padding-top: 0px; padding-bottom: 0px; background-color:#e6ae48;">
                        <div class=container>
                            <div class="limoking-stunning-item-ux limoking-ux">
                                <div class="limoking-item limoking-stunning-item">
                                    <div class=stunning-item-content>
                                        <h2 class="stunning-item-title" style=" color:black; ">What about pricing?</h2>
                                        <div class="stunning-item-caption limoking-skin-content" style=" color:black; ">Don’t worry. We provide very nice deals and the most competative price just for you!</div>
                                    </div><a class="stunning-item-button limoking-info-font" href=qoute.php style="color: #fff;background: #d3941f;">Request a qoute</a></div>
                            </div>
                            <div class=clear></div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-6>
                    <div class="limoking-parallax-wrapper limoking-background-image gdlr-show-all limoking-skin-dark-skin" id=limoking-parallax-wrapper-3 data-bgspeed=0 style="padding-top: 70px; ">
                        <div class=container>
                            <div class=limoking-title-item>
                                <div class="limoking-item-title-wrapper limoking-item  limoking-center-divider limoking-medium ">
                                    <div class="limoking-item-title-container container">
                                        <div class=limoking-item-title-head-inner>
                                            <div class="limoking-item-title-center-divider limoking-left"></div>
                                            <h3 class="limoking-item-title limoking-skin-title limoking-skin-border" style="color:black;">Our Services</h3>
                                            <div class="limoking-item-title-center-divider limoking-right"></div>
                                        </div>
                                        <div class="limoking-item-title-caption limoking-skin-info" style="color:black;">Highstar Limousine Inc. We will never cancel on you, our services are 100% guaranteed</div>
                                    </div>
                                </div>
                            </div>
                            <div class=clear></div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-7>
                    <div class="limoking-color-wrapper  gdlr-show-all no-skin" style="background-color: #ffffff; padding-top: 70px; padding-bottom: 20px; ">
                        <div class=container>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-11.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Night Parties</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>We are proud to say this, thousands of graduates enjoyed our most wonderful Prom Service. Our Limousine Service is always ready to pick you and your friends from your location and drop you off at your venue efficiently and safely. So, hire the best party limo company & enjoy a fantastic limo near your location</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-21.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Weddings</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>We provide our customers with supreme comfort and style. Our stunning wedding limousine fleet will leave everyone breathless, and have your trip in complete style. Finding a unique and convertible wedding limousine that fits with your wedding theme and makes it stand out from the crowd in a grand entrance, we make it perfect for your special day.</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-31.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Casinos</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>When you want to spend a night out with friends, there’s nothing more exciting than going to a casino. Casinos offer plenty of entertainment, dining and opportunities to bring home a little cash, too. What they don’t offer is transportation to and from their locations, which is where Premiere #1 Limousine can play a huge part in your next trip to the casino.</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class=clear></div>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-41.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Birthdays</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>HIGHSTAR LIMO offers superb lim service in New York and Manhatatan.  We are the most popular and has been chosen by many important people. We also provide premier service to the airport, wedding, casino, sport event, proms etc.</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-51.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Proms</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>The best way to celebrate prom nights and parties with friends is by getting a limousine party chauffeured service.</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class="four columns">
                                <div class="limoking-ux column-service-ux">
                                    <div class="limoking-item limoking-column-service-item limoking-medium" style="margin-bottom: 40px;">
                                        <div class=column-service-image><img src=upload/service-icon-61.png alt width=41 height=46></div>
                                        <div class=column-service-content-wrapper>
                                            <h3 class="column-service-title">Airport Transfers</h3>
                                            <div class="column-service-content limoking-skin-content">
                                                <p>Book your next Airport Ride to the JFK International Airport, LaGuardia Airport, Newark Airport, HPN Airport.</p>
                                            </div></div>
                                    </div>
                                </div>
                            </div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
                <section id=content-section-8>
                    <div class="limoking-full-size-wrapper gdlr-show-all no-skin" style="padding-bottom: 0px;  background-color: #ffffff; ">
                        <div class="limoking-master-slider-item limoking-slider-item limoking-item" style="margin-bottom: 0px;">
                            <div id=P_MS5c9b6f396d4d0 class="master-slider-parent ms-parent-id-2">
                                <div id=MS5c9b6f396d4d0 class="master-slider ms-skin-default">
                                    <div class=ms-slide data-delay=7 data-fill-mode=fill> <img src=plugins/masterslider/public/assets/css/blank.gif alt title data-src=upload/shutterstock_776694791.jpg>
                                        <video data-autopause=false data-mute=true data-loop=true data-fill-mode=fill>
                                            <source src=upload/service-video-bg-n.webm type=video/webm> </video>
                                        <div class="ms-layer  msp-cn-1-1" style data-ease=easeOutQuint data-offset-x=0 data-offset-y=-143 data-origin=mc data-position=normal> Or anywhere you need us to take</div>
                                        <div class="ms-layer  msp-cn-1-2" style data-ease=easeOutQuint data-offset-x=0 data-offset-y=-58 data-origin=mc data-position=normal> Not only taking to night parties, weddings, casinos, birthdays but
                                            <br/>we also take you to anywhere you want to go.</div>
                                        <div class="ms-layer  msp-cn-1-3" style data-ease=easeOutQuint data-offset-x=0 data-offset-y=24 data-origin=mc data-position=normal> Call Now +1 347-724-2108</div><img class=ms-layer src=plugins/masterslider/public/assets/css/blank.gif data-src=upload/slider-divider.png alt style data-ease=easeOutQuint data-type=image data-offset-x=81 data-offset-y=92 data-origin=mc data-position=normal><img class=ms-layer src=plugins/masterslider/public/assets/css/blank.gif data-src=upload/slider-divider.png alt style data-ease=easeOutQuint data-type=image data-offset-x=-79 data-offset-y=92 data-origin=mc data-position=normal>
                                        <div class="ms-layer  msp-cn-1-6" style data-ease=easeOutQuint data-offset-x=0 data-offset-y=95 data-origin=mc data-position=normal> OR</div><a href=reservation.php target=_self class="ms-layer  msp-cn-2-7 ms-btn ms-btn-round ms-btn-n msp-preset-btn-159" data-ease=easeOutQuint data-type=button data-offset-x=0 data-offset-y=173 data-origin=mc data-position=normal> Book Online</a></div>
                                </div>
                            </div>

                        </div>
                        <div class=clear></div>
                        <div class=clear></div>
                    </div>
                    <div class=clear></div>
                </section>
                
                <section id=content-section-10>
                    <div class="limoking-color-wrapper   " style="background-color: #ffffff; ">
                        <div class=container>
                            
                            <div class="twelve columns">
                                <div class=limoking-testimonial-item-wrapper>
                                    <div class="limoking-item-title-wrapper limoking-item  limoking-nav-container limoking-left limoking-small ">
                                        <div class="limoking-item-title-container container">
                                            <div class=limoking-item-title-head-inner>
                                                <h3 class="limoking-item-title limoking-skin-title limoking-skin-border">Testimonial</h3><span class=limoking-nav-title><i class="icon-angle-left limoking-flex-prev"></i><i class="icon-angle-right limoking-flex-next"></i></span></div>
                                        </div>
                                    </div>


                                    <section id=content-section-1>
                    <div class="limoking-color-wrapper  gdlr-show-all no-skin" style="background-color: #ffffff; padding-top: 75px; padding-bottom: 5px; ">
                        <div class=container>
                            <div class=limoking-testimonial-item-wrapper style="margin-bottom: 80px;">
                                <div class="limoking-item limoking-testimonial-item carousel round-style">
                                    <div class="limoking-ux limoking-testimonial-ux">
                                        <div class=flexslider data-type=carousel data-nav-container=limoking-testimonial-item data-columns=3>
                                            <ul class=slides>
                                                <li class=testimonial-item>
                                                    <div class="testimonial-item-inner limoking-skin-box">
                                                        <div class=testimonial-item-content-wrapper>
                                                            <div class="testimonial-content limoking-info-font limoking-skin-content">
                                                                <p>I don’t want anything to do with your competitors cause I think you are the best by far. Thumbs up for Highstar Limo services</p>
                                                            </div>
                                                            <div class=testimonial-info><span class="testimonial-author limoking-skin-link-color">John Dow<span>, </span></span><span class="testimonial-position limoking-skin-info">Head Chef</span></div>
                                                            <div class="testimonial-author-image limoking-skin-border"><img src=upload/testimonial-11-150x150.jpg alt width=150 height=150></div>
                                                            <div class=clear></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class=testimonial-item>
                                                    <div class="testimonial-item-inner limoking-skin-box">
                                                        <div class=testimonial-item-content-wrapper>
                                                            <div class="testimonial-content limoking-info-font limoking-skin-content">
                                                                <p>Thank you for really good service. We appreciate it and were just talking about how you stand out compared to other companies.</p>
                                                            </div>
                                                            <div class=testimonial-info><span class="testimonial-author limoking-skin-link-color">Ricardo Goff<span>, </span></span><span class="testimonial-position limoking-skin-info">Layers</span></div>
                                                            <div class="testimonial-author-image limoking-skin-border"><img src=upload/testimonial-21-150x150.jpg alt width=150 height=150></div>
                                                            <div class=clear></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class=testimonial-item>
                                                    <div class="testimonial-item-inner limoking-skin-box">
                                                        <div class=testimonial-item-content-wrapper>
                                                            <div class="testimonial-content limoking-info-font limoking-skin-content">
                                                                <p>My experience today was a 5 star. waiting when I walked out the door, helpful with luggage, timely arrival…hard to ask for more</p>
                                                            </div>
                                                            <div class=testimonial-info><span class="testimonial-author limoking-skin-link-color">Jennifer Dawn<span>, </span></span><span class="testimonial-position limoking-skin-info">Lawyer</span></div>
                                                            <div class="testimonial-author-image limoking-skin-border"><img src=upload/testimonial-31-150x150.jpg alt width=150 height=150></div>
                                                            <div class=clear></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class=testimonial-item>
                                                    <div class="testimonial-item-inner limoking-skin-box">
                                                        <div class=testimonial-item-content-wrapper>
                                                            <div class="testimonial-content limoking-info-font limoking-skin-content">
                                                                <p>Highstar Limo provided excellent service from start to finish. We will certainly call you the next time we travel. Thank you for a job well done!</p>
                                                            </div>
                                                            <div class=testimonial-info><span class="testimonial-author limoking-skin-link-color">Paul Smith<span>, </span></span><span class="testimonial-position limoking-skin-info">Doctor</span></div>
                                                            <div class="testimonial-author-image limoking-skin-border"><img src=upload/testimonial-41-150x150.jpg alt width=150 height=150></div>
                                                            <div class=clear></div>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class=testimonial-item>
                                                    <div class="testimonial-item-inner limoking-skin-box">
                                                        <div class=testimonial-item-content-wrapper>
                                                            <div class="testimonial-content limoking-info-font limoking-skin-content">
                                                                <p>The service and the driver were great this morning. Amazing experience. Hardly recommended for professionals</p>
                                                            </div>
                                                            <div class=testimonial-info><span class="testimonial-author limoking-skin-link-color">Alan Christier<span>, </span></span><span class="testimonial-position limoking-skin-info">Accountant</span></div>
                                                            <div class="testimonial-author-image limoking-skin-border"><img src=upload/testimonial-51-150x150.jpg alt width=150 height=150></div>
                                                            <div class=clear></div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=clear></div>
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>

                                </div>
                            </div>
                           
                            <div class=clear></div>
                        </div>
                    </div>
                    <div class=clear></div>
                </section>
            </div>
        </div>
        <div class=clear></div>
    </div>
    <?php include('footer.php');?>