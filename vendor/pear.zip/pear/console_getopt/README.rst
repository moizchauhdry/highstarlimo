*******************************************
Console_Getopt - Command-line option parser
*******************************************

This is a PHP implementation of "getopt" supporting both short and long options.
It helps parsing command line options in your PHP script.

Homepage: http://pear.php.net/package/Console_Getopt

.. image:: https://travis-ci.org/pear/Console_Getopt.svg?branch=master
    :target: https://travis-ci.org/pear/Console_Getopt


Alternatives
============

* Console_CommandLine__ (recommended)
* Console_GetoptPlus__

__ http://pear.php.net/package/Console_CommandLine
__ http://pear.php.net/package/Console_GetoptPlus


License
=======
BSD-2-Clause
